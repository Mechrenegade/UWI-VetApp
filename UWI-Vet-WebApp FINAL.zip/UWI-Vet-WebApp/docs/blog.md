# blog.md

## January

### Monday 21st January, 2019
Completed:
1. Project Scope document reviewed.
2. Blog/ Website started.
3. Team member roles assigned.

Incomplete 29th Jan :
1. Refined Project Scope document. (Due Monday 28th)
2. Workload Distribution.
3. Schedule & Workflow.

Meet with Dr. Anil and clarified further questions regarding the project. Decided to go with a Web App. Also he stated that internet availablilty is about 96%. 

## February 

### Monday 4th February, 2019
1. Complete Requirement Specification 
2. Start drawing up ERD's and Other diagrams
3. Start database work
4. 
  
### Friday 15th February, 2019 
1. Completed the project Scope Documentation 
2. Started work on the database. 
3. Database code (Flask) Databse Software (My SQL)
4. Completed the System Diagram. 

### Monday 18th February, 2019
1. Meet with Supervisor and discussed the Use Cases in further detail 
2. Got confirmation on the different use cases to do 
3. Got updates on System Architecture Diagram 
3. Got updated on System Requirements 

### Thursday 28th February, 2019 
1. Meet and discussed the Use Cases in further detail 
2. Presented a template for the Web App
3. Decided to go with Flask and MySql lite for the DB
4. Presented a bare-bones working template 

## March 


